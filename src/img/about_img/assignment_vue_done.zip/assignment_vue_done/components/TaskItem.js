export default {
  props: ["tasks"],
  emits: ["taskRemove", "taskEdit", "taskSwap", "taskStar"],
  template: `
    <li v-for="(task, index) in tasks" :key="task.id">
      <div class="item_flex">
        <div class="left_block">
          <div class="btn_flex">
            <button type="button" class="btn_up" @click="$emit('taskSwap', $event, index, 'up')">往上</button>
            <button type="button" class="btn_down" @click="$emit('taskSwap', $event, index, 'down')">往下</button>
          </div>
        </div>
        <div class="middle_block">
          <div class="star_block">
            <span class="star" :class="{'-on': task.star >= 1}" @click="$emit('taskStar', $event, index, 1)"><i class="fas fa-star"></i></span>
            <span class="star" :class="{'-on': task.star >= 2}" @click="$emit('taskStar', $event, index, 2)"><i class="fas fa-star"></i></span>
            <span class="star" :class="{'-on': task.star >= 3}" @click="$emit('taskStar', $event, index, 3)"><i class="fas fa-star"></i></span>
            <span class="star" :class="{'-on': task.star >= 4}" @click="$emit('taskStar', $event, index, 4)"><i class="fas fa-star"></i></span>
            <span class="star" :class="{'-on': task.star >= 5}" @click="$emit('taskStar', $event, index, 5)"><i class="fas fa-star"></i></span>
          </div>
          <p class="para" :class="{'-none': task.editable}">{{ task.name }}</p>
          <input type="text" class="task_name_update" :class="{'-none': !task.editable}" placeholder="更新待辦事項…" v-model.trim="task.name">
        </div>
        <div class="right_block">
          <div class="btn_flex">
            <button type="button" class="btn_update" @click="$emit('taskEdit', $event, index)">更新</button>
            <button type="button" class="btn_delete" @click="$emit('taskRemove', $event, index)">移除</button>
          </div>
        </div>
      </div>
    </li>
  `
}