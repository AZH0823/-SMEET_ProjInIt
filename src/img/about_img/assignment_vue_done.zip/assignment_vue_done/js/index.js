
import TaskItem from "../components/TaskItem.js";

const app = Vue.createApp({
  //components: { TaskItem },
  data(){
    return {
      taskText: "",
      tasks: [
        //{star: 1, name: "文字"}, // 一開始沒有 editable
      ]
    };
  },
  methods: {
    toggleShadow(e){
      //e.target.closest("div.task_add_block").classList.toggle("-on");
      this.$refs.taskAddBlock.classList.toggle("-on");
    },
    taskAdd(){
      //console.log(this.taskText);
      if(this.taskText != ""){
        //this.$refs.taskList.insertAdjacentHTML("afterbegin", ``);
        this.tasks.unshift({id: Date.now(), star: 0, name: this.taskText, editable: false});
        this.taskText = "";
      }
    },
    taskRemove(e, i){
      //console.log("aaaaa");
      let r = confirm("確認移除？");
      if(r){
        e.target.closest("li").classList.add("fade");
        setTimeout(() => {
          this.tasks.splice(i, 1);
        }, 1000);
      }
    },
    taskClear(){
      let r = confirm("確認清空？");
      if(r){
        for(let i = 0; i < this.$refs.taskList.children.length; i++){
          this.$refs.taskList.children[i].classList.add("fade");
        }
        setTimeout(() => {
          this.tasks = [];
        }, 1000);
      }
    },
    taskEdit(e, i){
      if(this.tasks[i].editable){
        //console.log(this.tasks[i].name);
        if(this.tasks[i].name == ""){
          alert("請輸入待辦事項");
        }else{
          this.tasks[i].editable = !this.tasks[i].editable;
        }
      }else{
        this.tasks[i].editable = !this.tasks[i].editable;
      }
    },
    taskSwap(e, i, direction){
      if(direction == "up" && i != 0){
        let temp = this.tasks[i];
        this.tasks[i] = this.tasks[i-1];
        this.tasks[i-1] = temp; 
      }
      if(direction == "down" && i != (this.tasks.length - 1)){
        let temp = this.tasks[i];
        this.tasks[i] = this.tasks[i+1];
        this.tasks[i+1] = temp;
      }
    },
    taskStar(e, i, star){
      this.tasks[i].star = star;
    }
  }
});

app.component("TaskItem", TaskItem);

const vm = app.mount("#task_container");
